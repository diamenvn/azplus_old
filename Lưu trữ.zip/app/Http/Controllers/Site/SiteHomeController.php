<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Model\Mysql\CustomerModel;
use App\Services\UserService;
use App\Services\PageService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SiteHomeController extends Controller
{
    private $pageService;
    private $userService;
    public function __construct(PageService $pageService, UserService $userService)
    {
      $this->page = $pageService;
      $this->user = $userService;
    }

    public function getPage(Request $req){
      switch ($req->type) {
        case '1':
          return $this->allPage();
          break;

        case '2':
          return $this->pageConneted();
          break;

        default:
          // code...
          break;
      }
    }

    public function allPage(){
      $token = $this->user->getUser()->token;
      $page = $this->page->getAllPage($token);
      return view('home.comment.index', compact(['page']));
    }

    public function pageConneted(){
      $page = $this->page->getPageConnected($this->user->getUser());
      return view('home.comment.index', compact(['page']));
    }

    public function detailPage($accessToken){
      $user = $this->user->getUser(); // User info
      $feed = $this->page->getFeed($accessToken); // Get all post in page
      $detailPage = $this->page->detailPage($accessToken); // Detail one post
      if ($detailPage){
        $this->page->connect($user, $detailPage); // Connect page to user
      }
      return view('home.comment.detailpage', compact(['feed', 'detailPage']));
    }

    public function addComment(){
      return view('home.comment.addcomment');
    }

    public function postComment(Request $request){
      $user = $this->user->getUser(); // User info
      $res['msg'] = "That bai";
      $res['error'] = 1;
      $request = $request->only(['id', 'data', 'time']);
      $pid = explode('_', $request['id'])[0];

      $data = array(
        'pid' => $pid,
        'fid' => $request['id'],
        'data' => $request['data'],
        'time' => $request['time']
      );
      $req = $this->page->addComment($user, $data);
      if ($req){
        $res['msg'] = "Thanh cong";
        $res['error'] = 0;
      }
      return response()->json($res);
    }

    public function postCommentToFacebook(){
      Storage::disk('local')->put('file.txt', date('Y-m-d H:i:s'));
      $this->page->postCommentToFacebook();
    }
}
