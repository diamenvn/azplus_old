<?php
namespace App\Services;

use Illuminate\Support\Facades\Auth;

class UserService
{

  public function __construct()
  {
    $this->userTableName = 'customer';
  }

  public function getUser() {
    return Auth::guard($this->userTableName)->user();
  }

  public function updateUser(){

  }

  public function createUser(){

  }

  public function deleteUser(){

  }
}


?>
