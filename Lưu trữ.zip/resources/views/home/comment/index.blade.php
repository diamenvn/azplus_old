@extends('home.layout')
@section('title', 'Bình luận')

@section('second-menu')
  <div class="row">
    <div class="col-12">
      <div class="panel sidetab-menu">
        <div class="panel-body">
          <h6 class="mt-3 mb-2"><i class="fal fa-dot-circle mr-1"></i>Loại trang</h6>
          <a class="slide-item" href="index.html"><i class="fal fa-chevron-double-right mr-1"></i> Tất cả trang</a>
          <a class="slide-item" href="index.html"><i class="fal fa-chevron-double-right mr-1"></i> Trang đã kết nối</a>
          <a class="slide-item" href="index.html"><i class="fal fa-chevron-double-right mr-1"></i> Trang chưa kết nối</a>
        </div>
      </div>
    </div>
  </div>
@endsection


@section('content')
<div class="app-content">
  <div class="section">
    <div class="row">
      <div class="col-xl-12 col-xs-12 col-lg-12">
        <div class="card">
          <div class="card-body">
            <div class="row">
              <div class="col-xl-10">
                <div class="input-group">
                  <input type="text" class="form-control br-tl-3  br-bl-3" placeholder="Tìm kiếm Fanpage của bạn ...">
                  <div class="input-group-append ">
                    <button type="button" class="btn btn-success br-tr-3  br-br-3"><i class="fal fa-search mr-2"></i>Tìm Kiếm</button>
                  </div>
                </div>
              </div>
              <div class="col-xl-2">
                <div class="mt-4 mt-xl-0">
                  <button type="button" class="btn btn-success btn-block pt-2 pb-2 text-size-14" data-toggle="modal" data-target="#exampleModal3">ADD<i class="fa fa-plus ml-2"></i></button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="main-body">
      <div class="row mt-4">
        @foreach($page as $value)
          <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
            <div class="card">
              <div class="card-header p-0">
                @if (isset($value['cover']))
                  <img src="{{$value['cover']['source']}}" alt="img" class="cover-image">
                @else
                  <img src="https://www.spruko.com/demo/dashlot/assets/images/media/p3.png" alt="img" class="cover-image">
                @endif
              </div>
              <div class="card-body">
                <div class="ibox">
                  <h4 class="teams-board-details mt-2 font-weight-semibold">{{$value['name']}}</h4>
                  <div> <span class="pr-2 text-muted h6"><i class="fal fa-tasks mr-2"></i>2 Nhắc nhở</span> <span class="pr-2 text-muted h6"><i class="fal fa-bell mr-2"></i>2 Thông báo</span> </div>
                  <div class="d-flex align-items-center"> <h5 class="mt-1">Trạng thái :</h5> <div class="badge badge-secondary ml-2">Chưa kết nối</div> </div>
                </div>
              </div>
              <div class="card-footer">
                <a href="{{route('detail-page', $value['access_token'])}}" class="btn btn-block btn-success">Sử dụng page này</a>
              </div>
            </div>
          </div>
        @endforeach
      </div>
    </div>



  </div>
</div>
@endsection
