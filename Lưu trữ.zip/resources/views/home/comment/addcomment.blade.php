@extends('home.layout')
@section('title', 'Chi tiết')

@section('second-menu')
  <div class="row">
    <div class="col-12 p-0">
      <div class="card border-0">
        <div class="card-header bg-white border-bottom-0">
          <div class="card-title">Lịch sử</div>
        </div>
        <div class="card-body border-0 coming-events p-0">
          <img src="https://www.spruko.com/demo/dashlot/assets/images/svg/calander2.svg" alt="" class="h-40 w-100">
          <div class="list-group pb-3 pt-3 history-comment">
            <div class="list-group-item d-flex p-0 border-0 align-items-center"> <div class="mr-2"> <i class="fal fa-calendar-alt"></i> </div> <div class=""> <div class=" h6 mb-0">Comment seeding</div> <small class="text-muted">19:00 15/11/2019</small> </div> </div>
            <div class="list-group-item d-flex p-0 border-0 align-items-center"> <div class="mr-2"> <i class="fal fa-calendar-alt"></i> </div> <div class=""> <div class=" h6 mb-0">Comment seeding</div> <small class="text-muted">19:00 15/11/2019</small> </div> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection


@section('content')
<div class="app-content">
  <div class="section">
    <div class="main-body">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <div class="card-title">Thêm bình luận</div>
            </div>
            <div class="card-body">
              <div class="richText">
                <div class="form-group">
                  <label for="comment">Nội dung bình luận</label>
                  <textarea class="form-control" rows="5" id="comment"></textarea>
                </div>
                <div class="form-group">
                  <label for="time">Lựa chọn thời gian</label>
                  <div class='input-group date' id='datetimepicker1'>
                    <input type='text' id="time" class="form-control" timepicker="true" />
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <button id="singlebutton" class="btn btn-primary center-block">
                      Xác Nhận
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
