@extends('home.layout')
@section('title', 'Chi tiết')

@section('second-menu')
  <div class="row">
    <div class="col-12 p-0">
      <div class="card border-0">
        <div class="card-header bg-white border-bottom-0">
          <div class="card-title">Lịch sử</div>
        </div>
        <div class="card-body border-0 coming-events p-0">
          <img src="https://www.spruko.com/demo/dashlot/assets/images/svg/calander2.svg" alt="" class="h-40 w-100">
          <div class="list-group pb-3 pt-3 history-comment">
            <div class="list-group-item d-flex p-0 border-0 align-items-center"> <div class="mr-2"> <i class="fal fa-calendar-alt"></i> </div> <div class=""> <div class=" h6 mb-0">Comment seeding</div> <small class="text-muted">19:00 15/11/2019</small> </div> </div>
            <div class="list-group-item d-flex p-0 border-0 align-items-center"> <div class="mr-2"> <i class="fal fa-calendar-alt"></i> </div> <div class=""> <div class=" h6 mb-0">Comment seeding</div> <small class="text-muted">19:00 15/11/2019</small> </div> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection


@section('content')
<div class="app-content">
  <div class="section">

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-header">
            <div class="card-title">Thông tin</div>
          </div>
          <div class="card-body p-4">
            <div class="row">
              <div class="col-lg-8 col-md-12">
                <div class="wideget-user-desc d-flex">
                  <div class="wideget-user-img mr-3">
                    <img class="avatar h-9 w-9 brround" src="{{$detailPage['picture']['data']['url']}}" alt="img">
                  </div>
                  <div class="user-wrap mt-0">
                    <h4 class="mb-2">{{$detailPage['name']}}</h4>
                    <h6 class="text-muted mb-3 fw-400">Member Since: November 2018</h6>
                    <a href="#" class="btn btn-primary mt-1 mb-1 mr-2"><i class="fa fa-briefcase mr-1"></i> Projects</a>
                    <a href="#" class="btn btn-secondary mt-1 mb-1"><i class="fa fa-envelope mr-1"></i> Message</a>
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12">
                <div class="row ml-3  ml-auto mt-lg-0">
                  <div class="col-xl-6 mt-5 mt-xl-0">
                    <div class="border-right pr-4 mt-xl-3 mt-lg-0 d-xl-block">
                      <p class="text-muted mb-3 fw-400 h5">Budget</p><h4 class="font-weight-semibold mb-0 ">$36,25,854</h4>
                    </div>
                  </div>
                  <div class="col-xl-6 mt-3 mt-xl-0">
                    <div class="pl-xl-4 pr-4 pl-md-0 pl-sm-0 pl-lg-0 mt-2 d-xl-block">
                      <p class="text-muted mb-3 fw-400 h5">Team Lead</p>
                      <h4 class="font-weight-semibold mb-0 ">John Wisely</h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="main-body">
      <div class="row mt-4">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <div class="card-title">DANH SÁCH BÀI VIẾT CỦA PAGE</div>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table card-table table-striped text-wrap">
                  <thead>
                    <tr>
                      <th style="width: 15%">Id</th>
                      <th style="max-width: 60%">Nội dung</th>
                      <th style="width: 130px">Thao tác</th>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach($feed as $value)
                      <tr>
                        <td>{{$value['created_time']}}</td>
                        <td>
                          @if(isset($value['message']))
                            {{$value['message']}}
                          @else
                            Bài viết không có nội dung
                          @endif
                        </td>
                        <td>
                          <div class="btn btn-primary btn-set-comment">
                            <a href="{{route('add-comment')}}/?id={{$value['id']}}">Sử dụng</a>
                          </div>
                        </td>
                      </tr>
                    @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
