<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <title>@yield('title')</title>
    @include('home.js')
    @include('home.css')
  </head>
  <body>
    <nav class="navbar navbar-header navbar-light">
      <div class="navbar-brand flex-center">
        <div id="logo"></div>
      </div>
      <div class="navbar-menu">
        <div class="navbar-item float-left">
          <div class="text time-expire">Hạn dùng: 10/12/2019</div>
          <div class="text text-upcase co-green bold">Gói dịch vụ: gói doanh nghiệp</div>
        </div>
        <div class="navbar-item flex-center float-right">
          <div class="icon flex-center">
            <i class="fal fa-envelope"></i>
          </div>
          <div class="icon flex-center">
            <i class="fal fa-bell"></i>
          </div>
          <div class="user flex-center">
            <i class="fal fa-user co-green"></i> <span class="ml-2 co-default">Onion9x</span>
          </div>
        </div>
      </div>
    </nav>
    <main>
      <div class="sidebar">
        <div class="sidebar-width sidebar-style d-flex">
          <div class="first-sidemenu">
            <ul>
              <li>
                <a class="sidebar-item" href="#">
                  <span><i class="fal fa-tachometer"></i></span>
                  <div>Trang chủ</div>
                </a>
              </li>
              <li>
                <a class="sidebar-item" href="#">
                  <span><i class="fal fa-reply-all"></i></span>
                  <div>Comment</div>
                </a>
              </li>
              <li>
                <a class="sidebar-item" href="#">
                  <span><i class="fal fa-inbox"></i></span>
                  <div>Tin nhắn</div>
                </a>
              </li>
              <li>
                <a class="sidebar-item" href="#">
                  <span><i class="fal fa-chart-line"></i></span>
                  <div>Báo cáo</div>
                </a>
              </li>
              <li>
                <a class="sidebar-item" href="#">
                  <span><i class="fal fa-user"></i></span>
                  <div>Khách hàng</div>
                </a>
              </li>

            </ul>

          </div>
          <div class="second-sidemenu">
            <div class="tab-menu-content">
              @yield('second-menu')
            </div>
          </div>
        </div>
      </div>
      <div class="main">
        @yield('content')
      </div>
    </main>
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 style="color:red;"><span class="glyphicon glyphicon-lock"></span> Login</h4>
            </div>
            <div class="modal-body">
              <form role="form">
                <div class="form-group">
                  <label for="usrname"><span class="glyphicon glyphicon-user"></span> Username</label>
                  <input type="text" class="form-control" id="usrname" placeholder="Enter email">
                </div>
                <div class="form-group">
                  <label for="psw"><span class="glyphicon glyphicon-eye-open"></span> Password</label>
                  <input type="text" class="form-control" id="psw" placeholder="Enter password">
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="" checked>Remember me</label>
                </div>
                <button type="submit" class="btn btn-default btn-success btn-block"><span class="glyphicon glyphicon-off"></span> Login</button>
              </form>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-default btn-default pull-left" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
              <p>Not a member? <a href="#">Sign Up</a></p>
              <p>Forgot <a href="#">Password?</a></p>
            </div>
          </div>
        </div>
      </div>
  </body>
</html>
