<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="{{asset('assets/site/theme/css/auth/app.css')}}">
<link rel="stylesheet" href="{{asset('assets/site/theme/css/layout/layout.css')}}">
<link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto:200,300,400,500,600,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{{asset('assets/site/theme/css/layout/font-awesome.css')}}">
<link rel="stylesheet" href="{{asset('assets/site/theme/css/layout/timepicker.css')}}">
